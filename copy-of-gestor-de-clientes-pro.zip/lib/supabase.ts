
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = 'https://gsreyvlisxlkurixrikx.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdzcmV5dmxpc3hsa3VyaXhyaWt4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAyNTAwMjIsImV4cCI6MjA4NTgyNjAyMn0.gR80WV_2yqILqZZqP79Jfs_6KMJTRdl-82JDN_7wegY';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
