
import { supabase } from '../lib/supabase';
import { Customer, UserProfile } from '../types';

export const authService = {
  async signUp(email: string, pass: string, companyName: string, name: string) {
    // 1. Criar usuário no Auth do Supabase
    const { data: authData, error: authError } = await supabase.auth.signUp({ 
      email, 
      password: pass 
    });
    
    if (authError) {
      if (authError.message.includes("already registered")) {
        throw new Error("Este e-mail já está sendo utilizado por outra empresa.");
      }
      if (authError.message.includes("Password should be")) {
        throw new Error("A senha deve ter pelo menos 6 caracteres.");
      }
      throw authError;
    }

    if (!authData.user) throw new Error("Não foi possível criar a conta. Tente novamente.");

    // 2. Criar ou atualizar perfil na tabela 'profiles'
    const { error: profileError } = await supabase
      .from('profiles')
      .upsert({
        id: authData.user.id,
        email,
        company_name: companyName,
        responsible_name: name,
        accepted_terms: true,
        updated_at: new Date().toISOString()
      });

    if (profileError) {
      console.error("Erro ao salvar perfil:", profileError);
      // Se o erro for de RLS ou tabela inexistente, o sistema ainda funciona mas o perfil fica incompleto
    }

    return authData.user;
  },

  async signIn(email: string, pass: string) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: pass });
    
    if (error) {
      if (error.message.includes("Invalid login credentials") || error.message.includes("does not exist")) {
        throw new Error("E-mail ou senha incorretos.");
      }
      if (error.message.includes("Email not confirmed")) {
        throw new Error("Sua conta ainda não foi confirmada. Verifique seu e-mail.");
      }
      throw error;
    }
    
    if (!data.user) throw new Error("Falha na autenticação.");
    return data.user;
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  async getProfile(userId: string): Promise<UserProfile> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) {
      console.error("Erro ao buscar perfil:", error);
      throw new Error("Erro de conexão ao carregar perfil.");
    }

    if (!data) {
      // Caso o perfil não exista (erro de criação no signup), retornamos um objeto básico para não travar o app
      return {
        id: userId,
        email: '',
        company_name: 'Empresa sem Nome',
        responsible_name: 'Usuário',
        accepted_terms: true,
        created_at: new Date().toISOString()
      };
    }
    return data;
  },

  async getCurrentUser() {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error) return null;
    return user;
  }
};

export const customerService = {
  async fetchAll(empresaId: string): Promise<Customer[]> {
    const { data, error } = await supabase
      .from('customers')
      .select('*')
      .eq('empresa_id', empresaId)
      .eq('is_deleted', false)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async save(customer: Partial<Customer>): Promise<Customer> {
    const { data, error } = await supabase
      .from('customers')
      .upsert({ 
        ...customer,
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async hardDelete(id: string, empresaId: string): Promise<void> {
    const { error } = await supabase
      .from('customers')
      .delete()
      .eq('id', id)
      .eq('empresa_id', empresaId);

    if (error) throw error;
  }
};
