
import { Customer, CustomerStatus, UserProfile } from '../types';

const STORAGE_KEY = 'gestor_clientes_data';
const AUTH_KEY = 'gestor_clientes_auth';

export const storageService = {
  getCustomers: (): Customer[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return [];
    // Fix: The property name in Customer interface is is_deleted (snake_case)
    return JSON.parse(data).filter((c: Customer) => !c.is_deleted);
  },

  saveCustomer: (customer: Customer): void => {
    const customers = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const index = customers.findIndex((c: any) => c.id === customer.id);
    
    if (index >= 0) {
      customers[index] = customer;
    } else {
      customers.push(customer);
    }
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(customers));
  },

  deleteCustomer: (id: string): void => {
    const customers = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const updated = customers.map((c: Customer) => 
      // Fix: The property name in Customer interface is is_deleted (snake_case)
      c.id === id ? { ...c, is_deleted: true } : c
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  },

  getStats: () => {
    const customers = storageService.getCustomers();
    return {
      total: customers.length,
      active: customers.filter(c => c.status === CustomerStatus.ACTIVE).length,
      inactive: customers.filter(c => c.status === CustomerStatus.INACTIVE).length,
      pending: customers.filter(c => c.status === CustomerStatus.PENDING).length,
    };
  },

  // Fix: UserAccount does not exist in types.ts, replacing with UserProfile
  createAccount: (account: UserProfile) => {
    localStorage.setItem(AUTH_KEY, JSON.stringify({ isLoggedIn: true, user: account }));
  },

  login: (email: string) => {
    // In this simple version, we reuse the existing account or create a dummy one if not exists
    const existing = storageService.getAuth();
    const user = existing.user || { email, companyName: 'Minha Empresa', responsibleName: 'Usuário' };
    localStorage.setItem(AUTH_KEY, JSON.stringify({ isLoggedIn: true, user: { ...user, email } }));
  },

  logout: () => {
    localStorage.removeItem(AUTH_KEY);
  },

  getAuth: () => {
    const data = localStorage.getItem(AUTH_KEY);
    return data ? JSON.parse(data) : { isLoggedIn: false, user: null };
  }
};
